#!/bin/bash
set -u
# Invoke with a clean outer environment. Paths are supplied by the existing cloud task.
[ "$#" -eq 5 ] || { echo 'usage: run-cloud.sh CANDIDATE_ROOT BASELINE_ROOT NODE_BINARY NEW_EVIDENCE_ROOT TRANSFER_CLOSURE' >&2; exit 90; }
candidate=$1
baseline=$2
node=$3
out=$4
closure=$5
mkdir "$out" || exit 91
cd "$candidate" || exit 92
/usr/bin/python3 -I - "$candidate" "$baseline" "$node" "$out" "$closure" <<'PY' > "$out/preflight.log" 2>&1
import hashlib,json,pathlib,sys
candidate,baseline,node,out,closure=map(pathlib.Path,sys.argv[1:]);data=json.loads(closure.read_text());assert hashlib.sha256(closure.read_bytes()).hexdigest()=='14826eb1ff3b6b8a31143e4afab5bced671a061e33c4dd09a02d6ece37ebcffd'
pins={}
for name,h in data['candidateFiles'].items():pins[str(candidate/name)]=h
for name,h in data['baselineFiles'].items():pins[str(baseline/name)]=h
for name,h in data['fixtures'].items():pins[str(baseline/'verification'/name)]=h
pins[str(node)]=data['invocation']['nodeSha256'];bad=[]
for name,h in pins.items():
 p=pathlib.Path(name)
 if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:bad.append(name)
manifest={'schema':'closed-loop-owned-native-cloud-translated-input-manifest/1','transferClosureSha256':hashlib.sha256(closure.read_bytes()).hexdigest(),'candidateRoot':str(candidate),'baselineRoot':str(baseline),'sha256':pins,'allowedCompositionDifference':data['allowedCompositionDifference']}
(out/'translated-input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'checkedInputs':len(pins),'unchanged':not bad,'mismatches':bad}));assert not bad,bad
PY
preflight=$?
[ "$preflight" -eq 0 ] || { echo "preflight_exit=$preflight" > "$out/terminal.txt"; cat "$out/preflight.log"; exit 93; }
{ sha256sum "$node"; "$node" --version; df -B1 "$candidate"; free -b; } > "$out/runtime-resources.log"
[ "$("$node" --version)" = v22.23.3 ] || { echo runtime_version_mismatch > "$out/terminal.txt"; exit 94; }
ulimit -c 0
{ echo "start=$(date -u +%Y-%m-%dT%H:%M:%SZ)"; echo "cwd=$PWD"; printf 'command=env -i PATH=/usr/bin:/bin CLRT_NATIVE_BASE=%q /usr/bin/timeout --signal=TERM --kill-after=5s 600s %q --max-old-space-size=4096 test-owned-native-routes.mjs --stage7\n' "$baseline" "$node"; echo core_limit=0; } > "$out/terminal.txt"
env -i PATH=/usr/bin:/bin CLRT_NATIVE_BASE="$baseline" /usr/bin/timeout --signal=TERM --kill-after=5s 600s "$node" --max-old-space-size=4096 test-owned-native-routes.mjs --stage7 > "$out/stage7.log" 2>&1
code=$?
{ echo "end=$(date -u +%Y-%m-%dT%H:%M:%SZ)"; echo "exit=$code"; } >> "$out/terminal.txt"
/usr/bin/python3 -I - "$out" <<'PY'
import hashlib,json,pathlib,sys
out=pathlib.Path(sys.argv[1]);m=json.loads((out/'translated-input-manifest.json').read_text());bad=[]
for name,h in m['sha256'].items():
 p=pathlib.Path(name)
 if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:bad.append(name)
result={'checkedInputs':len(m['sha256']),'unchanged':not bad,'mismatches':bad,'rawLogSha256':hashlib.sha256((out/'stage7.log').read_bytes()).hexdigest(),'rawLogByteSize':(out/'stage7.log').stat().st_size}
(out/'postflight.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));assert not bad,bad
PY
postflight=$?
echo "postflight_exit=$postflight" >> "$out/terminal.txt"
cat "$out/terminal.txt"
[ "$postflight" -eq 0 ] || exit 95
exit "$code"
